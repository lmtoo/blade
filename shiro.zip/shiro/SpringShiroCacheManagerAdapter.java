package cn.accessbright.blade.security.shiro;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheException;
import org.apache.shiro.cache.CacheManager;

public class SpringShiroCacheManagerAdapter implements CacheManager {
	private org.springframework.cache.CacheManager cacheManager;

	public SpringShiroCacheManagerAdapter(org.springframework.cache.CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}

	@Override
	@SuppressWarnings("unchecked")
	public <K, V> Cache<K, V> getCache(String name) throws CacheException {
		return (Cache<K, V>) cacheManager.getCache(name);
	}
}
